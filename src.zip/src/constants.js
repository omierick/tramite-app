// src/constants.js

export const ESTADOS_TRAMITE = {
    PENDIENTE: "Pendiente",
    APROBADO: "Aprobado",
    RECHAZADO: "Rechazado",
  };