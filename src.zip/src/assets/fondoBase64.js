// src/assets/fondoBase64.js

import base64 from "./UR-003-AUTORIZACIÓN-DE-LOTIFICACIÓN.base64?raw";

export const fondoBase64 = `data:image/jpeg;base64,${base64}`;
